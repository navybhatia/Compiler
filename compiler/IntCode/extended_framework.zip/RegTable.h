#ifndef REGTABLE_H
#define REGTABLE_H
#include <iostream>
#include <map>
#include <list>
#include <utility> // make_pair
#include <stdlib.h>
#include <stdio.h>
#define ERROR -1
#define SUCCESS 0
using namespace std;
class MapEntry;
class RegTable;

class MapEntry
{
	int reg;
	int memaddr;
    public: 
	MapEntry(int address)
	{
		memaddr=address;
		//reg=-1 denotes not in register
		reg=-1;
	}
	
	int setReg(int r)
	{
		reg=r;
	}	
	int getEntry()
	{
		if(reg!=-1)
			return reg;
		else
			return memaddr;
	}
	
};
typedef map<string, MapEntry*> mapType;
class RegTable
{
	private:
		mapType Map;
		list<string> freeIntList;
		list<string> freeFloatList;
		list<string> usedIntList;
		list<string> usedFloatList;
	public:
		RegTable()
		{
			
			for(int i=0;i<1000;i++)
			{
				char *r,*f;
				r=new char[4];
				f=new char[4];								
				sprintf(r,"r%03d",i);
				sprintf(f,"f%03d",i);
				freeIntList.push_back(r);
				freeFloatList.push_back(f);
			}		
			
		}
	        int insert(string key,MapEntry* r);
	        MapEntry* search(string key);
                int del(string key);
		void print();
		void printUsedIntList();
		void printUsedFloatList();
		int update(string key,MapEntry *value);
		string getFreeIntReg();
		string getFreeFloatReg();
		int delReg(string key);
};
#endif
